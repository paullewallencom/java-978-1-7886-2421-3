package Section_1;


@FunctionalInterface
public interface OneArgumentStatement<E> {
    void doSomething(E argument);
}
