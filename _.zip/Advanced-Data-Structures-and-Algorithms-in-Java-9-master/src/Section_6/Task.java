package Section_6;

public interface Task {

}
